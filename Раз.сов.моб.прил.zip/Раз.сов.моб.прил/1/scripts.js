function testFunction() {
    alert("Код выполняется!");
}

// Объекты

// 1. Подсчет количества свойств в объекте
function countProperties(obj) {
    let propertyCount = 0;
    const keysArray = Object.keys(obj);
    for (let i = 0; i < keysArray.length; i++) {
        propertyCount = propertyCount + 1;
    }
    return propertyCount;
}
const user = { name: "Alice", age: 25, city: "New York" };
console.log(countProperties(user)); // 3

// 2. Проверка наличия свойства в объекте
function hasProperty(obj, key) {
    let exists = false;
    for (let prop in obj) {
        if (prop === key) {
            exists = true;
            break;
        }
    }
    return exists;
}
const person = { name: "Bob", age: 30 };
console.log(hasProperty(person, "age")); // true

// 3. Объединение двух объектов
function mergeObjects(obj1, obj2) {
    let resultObject = {};
    for (let key in obj1) {
        if (obj1.hasOwnProperty(key)) {
            resultObject[key] = obj1[key];
        }
    }
    for (let key in obj2) {
        if (obj2.hasOwnProperty(key)) {
            resultObject[key] = obj2[key];
        }
    }
    return resultObject;
}
const obj1 = { name: "Alice", age: 25 };
const obj2 = { age: 30, city: "London" };
console.log(mergeObjects(obj1, obj2)); // { name: "Alice", age: 30, city: "London" }

// 4. Получение всех ключей объекта
function getObjectKeys(obj) {
    let keysArray = [];
    for (let key in obj) {
        if (obj.hasOwnProperty(key)) {
            keysArray.push(key);
        }
    }
    return keysArray;
}
const car = { brand: "Toyota", model: "Camry", year: 2022 };
console.log(getObjectKeys(car)); // ["brand", "model", "year"]

// 5. Удаление свойства из объекта
function removeProperty(obj, key) {
    let propertyExists = false;
    for (let prop in obj) {
        if (prop === key) {
            propertyExists = true;
            break;
        }
    }
    if (propertyExists) {
        delete obj[key];
    }
}
const book = { title: "1984", author: "George Orwell", year: 1949 };
removeProperty(book, "year");
console.log(book); // { title: "1984", author: "George Orwell" }

// Функции

// 1. Функция для вычисления факториала
function factorial(n) {
    let result = 1;
    if (n < 0) {
        return undefined;
    }
    if (n === 0) {
        return result;
    }
    for (let i = 1; i <= n; i++) {
        result = result * i;
    }
    return result;
}
console.log(factorial(5)); // 120

// 2. Функция для проверки, является ли число простым
function isPrime(n) {
    let isPrimeNumber = true;
    if (n <= 1) {
        isPrimeNumber = false;
    } else {
        for (let i = 2; i <= Math.sqrt(n); i++) {
            if (n % i === 0) {
                isPrimeNumber = false;
                break;
            }
        }
    }
    return isPrimeNumber;
}
console.log(isPrime(7)); // true

// 3. Функция, возвращающая сумму всех аргументов
function sumAll(...numbers) {
    let totalSum = 0;
    for (let i = 0; i < numbers.length; i++) {
        totalSum = totalSum + numbers[i];
    }
    return totalSum;
}
console.log(sumAll(1, 2, 3, 4)); // 10

// 4. Функция, которая переворачивает строку
function reverseString(str) {
    let reversedStr = '';
    for (let i = str.length - 1; i >= 0; i--) {
        reversedStr = reversedStr + str[i];
    }
    return reversedStr;
}
console.log(reverseString("hello")); // "olleh"

// 5. Функция, которая форматирует имя
function formatName(name) {
    let formattedName = '';
    if (name.length > 0) {
        let firstChar = name[0].toUpperCase();
        let restOfString = name.slice(1).toLowerCase();
        formattedName = firstChar + restOfString;
    }
    return formattedName;
}
console.log(formatName("aLiCe")); // "Alice"

// Массивы

// 1. Функция для нахождения максимального элемента в массиве
function findMax(arr) {
    let maxValue = arr[0];
    for (let i = 1; i < arr.length; i++) {
        if (arr[i] > maxValue) {
            maxValue = arr[i];
        }
    }
    return maxValue;
}
console.log(findMax([3, 7, 2, 9, 5])); // 9

// 2. Функция для фильтрации четных чисел из массива
function filterEvenNumbers(arr) {
    let evenNumbers = [];
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] % 2 === 0) {
            evenNumbers.push(arr[i]);
        }
    }
    return evenNumbers;
}
console.log(filterEvenNumbers([1, 2, 3, 4, 5, 6])); // [2, 4, 6]

// 3. Функция для объединения двух массивов без дубликатов
function mergeUnique(arr1, arr2) {
    let combinedArray = [];
    for (let i = 0; i < arr1.length; i++) {
        combinedArray.push(arr1[i]);
    }
    for (let i = 0; i < arr2.length; i++) {
        let isDuplicate = false;
        for (let j = 0; j < combinedArray.length; j++) {
            if (arr2[i] === combinedArray[j]) {
                isDuplicate = true;
                break;
            }
        }
        if (!isDuplicate) {
            combinedArray.push(arr2[i]);
        }
    }
    return combinedArray;
}
console.log(mergeUnique([1, 2, 3], [3, 4, 5])); // [1, 2, 3, 4, 5]

// 4. Функция для переворота массива
function reverseArray(arr) {
    let reversedArray = [];
    for (let i = arr.length - 1; i >= 0; i--) {
        reversedArray.push(arr[i]);
    }
    return reversedArray;
}
console.log(reverseArray([1, 2, 3])); // [3, 2, 1]

// 5. Функция для поиска индекса элемента в массиве
function findIndex(arr, value) {
    let foundIndex = -1;
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] === value) {
            foundIndex = i;
            break;
        }
    }
    return foundIndex;
}
console.log(findIndex([10, 20, 30, 40], 30)); // 2